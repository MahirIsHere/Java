/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ceramics;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author AKRAM
 */
public class ForntPageController implements Initializable {

    @FXML
    private TextField userIDTextField;
    @FXML
    private ComboBox comboBox;
    @FXML
    private TextArea outputTextArea;
    @FXML
    private Label statusLabel;
    @FXML
    private PasswordField passwordTextField;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        comboBox.getItems().addAll("Manager","Supplier","Owner","FinanceAndAccount_Officer"
        ,"Marketing_Dealer");
        
        comboBox.setValue("Manager");
    }    

    @FXML
    private void loginBtnOnClick(ActionEvent event) {
        outputTextArea.setVisible(true);
        
           
        
        String id = userIDTextField.getText();
        String password = passwordTextField.getText();
        String type = comboBox.getValue().toString();
        
        
        File f = null;
        FileInputStream fis = null;
        //BufferedInputStream bis = null;
        DataInputStream dis = null;
      
        try {
            f = new File("login.bin");
            if(!f.exists()){
              outputTextArea.setText("login.bin file doesn't exist!");
            }
            else{
                
                fis = new FileInputStream(f);
            
                dis = new DataInputStream(fis);
               
                while(true){
                    if(id.equals(dis.readUTF()))
                    {
                        if(password.equals(dis.readUTF()))
                        {
                            if(type.equals(dis.readUTF()))
                            {
                                
                               outputTextArea.setText("login successfull !");
                               goToScene2(type,event);
                               break;
                            }
                        }
                    }
                    
                    
                }
                
            }
        } catch (Exception ex) 
        {
           outputTextArea.setText("login failed!");
            
        } finally {
            try {
                if(dis != null) dis.close();
            } catch (Exception ex) {
              
            }
        }
    }

    @FXML
    private void signupBtnOnClick(ActionEvent event) {
        outputTextArea.setVisible(true);
        
        String id = userIDTextField.getText();
        String password = passwordTextField.getText();
        String type = comboBox.getValue().toString();
        
        
        File f = null;
        FileOutputStream fos = null;
        BufferedOutputStream bos = null;
        DataOutputStream dos = null;
        
        try {
            f = new File("login.bin");
            if(f.exists()) fos = new FileOutputStream(f,true);
            else fos = new FileOutputStream(f);
            
            bos = new BufferedOutputStream(fos);
            dos = new DataOutputStream(bos);
            //dos = new DataOutputStream(fos);
            
           
            dos.writeUTF(id);
            dos.writeUTF(password);
            dos.writeUTF(type);
            
            outputTextArea.setText("User Registration Successfull! Now go back to login scene");
            
            


        } catch (Exception e) 
        {
            outputTextArea.setText("User Registration Failed!");
           
            
        } finally {
            try {
                if(dos != null) dos.close();
              
            } catch (Exception ex) {
                
            }
        }
    
    }

    private void goToScene2(String type, ActionEvent event) throws IOException
    {
        
        //Manager","Supplier","Owner","FinanceAndAccount_Officer"
       // ,"Marketing_Dealer"
        
        
        if(type.equals("Manager"))
        {
            
         Parent scene2Parent = FXMLLoader.load(getClass().getResource("ManagerHomePage.fxml"));
         Scene scene2 = new Scene(scene2Parent);
         Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
         window.setScene(scene2);
         window.show();
        }
        
        else if(type.equals("Supplier"))
        {
          Parent scene2Parent = FXMLLoader.load(getClass().getResource("SupplierHomePage.fxml"));
         Scene scene2 = new Scene(scene2Parent);
         Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
         window.setScene(scene2);
         window.show();
        }
          else if(type.equals("Owner"))
        {
              Parent scene2Parent = FXMLLoader.load(getClass().getResource("OwnerHomePage.fxml"));
         Scene scene2 = new Scene(scene2Parent);
         Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
         window.setScene(scene2);
         window.show();
            
        }
            else if(type.equals("FinanceAndAccount_Officer"))
        {
              Parent scene2Parent = FXMLLoader.load(getClass().getResource("FinanceOfficerHomePage.fxml"));
         Scene scene2 = new Scene(scene2Parent);
         Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
         window.setScene(scene2);
         window.show();
        }
            else if(type.equals("Marketing_Dealer"))
        {
          Parent scene2Parent = FXMLLoader.load(getClass().getResource("MarketingDealerHomePage.fxml"));
         Scene scene2 = new Scene(scene2Parent);
         Stage window = (Stage)((Node)event.getSource()).getScene().getWindow();
        
         window.setScene(scene2);
         window.show();
            
        }  
        
    }
    
}
